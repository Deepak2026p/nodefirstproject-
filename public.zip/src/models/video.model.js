import PG, { Schema } from "pg";
import knex from 'knex';
import { attachPaginate } from 'knex-paginate';
const videoSchema = new PG.Schema(
    {
        videoFile: {
            type: String, //cloudinary url
            required: [true, "Video file is required"],
        },
        thumbnail: {
            type: String, //cloudinary url
            required: [true, "Thumbnail is required"],
        },
        title: {
            type: String,
            required: [true, "Title is required"],

        },
        description: {
            type: String,
            required: [true, "Description is required"],
        },
        duration: {
            type: Number,
            required: [true, "Duration is required"],
        },
        views: {
            type: Number,
            default: 0
        },
        isPublished: {
            type: Boolean,
            default: true
        },
        owner: {
            type: Schema.Types.ObjectId,
            ref: "User",
        }
    },
    {
        timestamps: true,
    }
)

videoSchema.plugin(attachPaginate);
export const Video = PG.model("Video", videoSchema);